/** OneFolk cloud sender/monitor for the existing master Google Sheet.
 * Install as a BOUND Apps Script: open spreadsheet > Extensions > Apps Script.
 * Setup: set SPREADSHEET_ID in Script Properties, run installTriggers() and authorize.
 * All sending is disabled until Script Property ENABLE_SENDING = YES.
 */
const QUEUE='Lead Queue';
const HEADERS=['lead_id','business','industry','website','source_url','public_email','email_source_url','observation','observation_url','proof_project','proof_line','subject','email_body','status','approval','sent_at','gmail_message_id','reply_status','notes','updated_at'];
const BLOCKED=['info@drkumudiniaestheticgynae.com','team@studioamamumbai.com','contact@amazeoneinteriors.com','riointeriorsdesigner@gmail.com','studioha@gmail.com','hello@goristore.com','info@arch4foundation.com','dbs4mee@gmail.com'];
const MAX_PER_DAY=50;
function cfg(k){return PropertiesService.getScriptProperties().getProperty(k)||'';}
function book(){return SpreadsheetApp.openById(cfg('SPREADSHEET_ID'));}
function getQueue(){let s=book().getSheetByName(QUEUE);if(!s)throw Error('Lead Queue does not exist. Run discovery once.');return s;}
function rows(sheet){let a=sheet.getDataRange().getValues();return a.slice(1).map((v,i)=>({r:i+2,v}));}
function key(s){return String(s||'').trim().toLowerCase();}
function domain(url){try{return String(url).replace(/^https?:\/\//,'').split('/')[0].replace(/^www\./,'').toLowerCase();}catch(e){return '';}}
function sentToday(){let d=Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyy-MM-dd');let p=PropertiesService.getScriptProperties();return Number(p.getProperty('SENT_'+d)||0);}
function increment(){let d=Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyy-MM-dd');let p=PropertiesService.getScriptProperties();p.setProperty('SENT_'+d,String(sentToday()+1));}
function suppression(){let set=new Set(BLOCKED);let q=getQueue();for(const r of rows(q)){let st=key(r.v[13]);if(['bounced','declined','unsubscribed','suppressed'].includes(st)){set.add(key(r.v[5]));set.add(domain(r.v[3]));}}let hist=book().getSheetByName('Sent Emails');if(hist){for(let r of hist.getDataRange().getValues().slice(1)){if(r.length>1)set.add(key(r[1]));}}return set;}
function valid(row){let v=row.v, to=key(v[5]),subject=String(v[11]||'').trim(),body=String(v[12]||'').trim();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to))return false;
  if(!v[6]||!v[8]||!v[10]||!subject||!body)return false;
  if(body.trim().split(/\s+/).length>70)return false;
  if(body.split(/\n\s*\n/).filter(Boolean).length!==3)return false;
  if(!/^https?:\/\//.test(String(v[8])))return false;
  if(key(v[13])!=='approved'||key(v[14])!=='approved')return false;
  if(v[15]||v[16])return false;
  return true;
}
function approvedSender(){
  if(cfg('ENABLE_SENDING')!=='YES'){Logger.log('DRY RUN: sender disabled');return;}
  let lock=LockService.getScriptLock();if(!lock.tryLock(10000))return;
  try{
    let sheet=getQueue(),blocked=suppression(),used=sentToday(),quota=MailApp.getRemainingDailyQuota();
    let budget=Math.min(MAX_PER_DAY-used,quota);if(budget<=0)return;
    const existing=new Set();
    for(let row of rows(sheet)){
      if(budget<=0)break;
      let v=row.v,to=key(v[5]),host=domain(v[3]);
      if(blocked.has(to)||blocked.has(host)||existing.has(to))continue;
      existing.add(to);
      if(!valid(row))continue;
      // reserve row first; ambiguous provider timeouts require manual reconciliation, NOT blind resend
      sheet.getRange(row.r,14).setValue('SENDING');SpreadsheetApp.flush();
      try{
        let body=String(v[12]).trim()+'\n\nRegards,\nTeam OneFolk\nhttps://onefolk.in/work';
        GmailApp.sendEmail(to,String(v[11]).trim(),body,{name:'Team OneFolk'});
        increment();budget--;blocked.add(to);
        sheet.getRange(row.r,14).setValue('SENT');
        sheet.getRange(row.r,16).setValue(new Date());
        sheet.getRange(row.r,19).setValue('Sent via GmailApp; ID not returned by this API');
        sheet.getRange(row.r,20).setValue(new Date());
      }catch(e){sheet.getRange(row.r,14).setValue('SEND_REVIEW');sheet.getRange(row.r,19).setValue(String(e).slice(0,400));}
    }
  }finally{lock.releaseLock();}
}
function monitorReplies(){
  let sh=getQueue(),items=rows(sh),sent=items.filter(x=>['sent','sending','send_review'].includes(key(x.v[13])));
  if(!sent.length)return;
  // Strictly match source email addresses and thread context; classify ambiguous replies for review.
  let map=new Map(sent.map(x=>[key(x.v[5]),x]));
  const msgs=GmailApp.search('in:inbox newer_than:14d',0,200);
  for(const thread of msgs){for(const msg of thread.getMessages()){

    const from=String(msg.getFrom()||'');let sender=(from.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)||[])[0];sender=key(sender);
    const body=msg.getPlainBody().slice(0,1200),sub=msg.getSubject();
    if(map.has(sender)){
      let row=map.get(sender);
      let declined=/not interested|remove me|unsubscribe|do not contact/i.test(body);
      sh.getRange(row.r,18).setValue(declined?'DECLINED':'REPLY_REVIEW');
      if(declined)sh.getRange(row.r,14).setValue('DECLINED');
      sh.getRange(row.r,20).setValue(new Date());
    }
    if(/delivery status notification|undelivered mail/i.test(sub)){
      const match=body.match(/(?:Final-Recipient:\s*rfc822;\s*|couldn't be delivered to\s*|wasn't delivered to\s*)([\w.+-]+@[\w.-]+)/i);
      if(match&&map.has(key(match[1]))){let row=map.get(key(match[1]));sh.getRange(row.r,14).setValue('BOUNCED');sh.getRange(row.r,18).setValue('BOUNCED');sh.getRange(row.r,20).setValue(new Date());}
    }
  }}
}
function installTriggers(){
  for(const trigger of ScriptApp.getProjectTriggers())if(['approvedSender','monitorReplies'].includes(trigger.getHandlerFunction()))ScriptApp.deleteTrigger(trigger);
  ScriptApp.newTrigger('approvedSender').timeBased().everyHours(1).create();
  ScriptApp.newTrigger('monitorReplies').timeBased().everyHours(2).create();
  Logger.log('Triggers installed. Sending remains OFF until ENABLE_SENDING is YES.');
}
