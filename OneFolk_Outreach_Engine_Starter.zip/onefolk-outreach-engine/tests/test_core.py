from src.discover import domain, valid_email, safe_url

def test_domain():
    assert domain('https://www.example.edu/admissions')=='example.edu'

def test_email_scope():
    assert valid_email('info@example.edu','example.edu')
    assert not valid_email('test@gmail.com','example.edu')

def test_url_filter():
    assert not safe_url('http://127.0.0.1/admin')
    assert not safe_url('file:///etc/passwd')
    assert safe_url('https://example.edu/')
