# OneFolk Outreach Engine — free-tier cloud starter

**Status:** Deployable starter, not a production-proven lead generator. **No sending by default.**

## Architecture

- GitHub Actions (private repository, scheduled) runs Python website discovery and research.
- Sources: manually curated `config/seeds.csv` and permitted public directory pages in `config/directories.csv`.
- Public first-party business-domain contact emails only. No guessing, no paid enrichment, no Google Maps scraping by default.
- Groq free API produces a three-paragraph draft (under 70 words) **only with a sourced website opportunity** and a fixed, supplied OneFolk proof line. Groq errors or exhausted quota => skip; no paid fallback.
- Google Sheets `Lead Queue` contains drafts. `approval=APPROVED` and `status=APPROVED` are both mandatory.
- Bound Google Apps Script sends via the owner's Gmail account, max **50 per day**, after manual approval. Default `ENABLE_SENDING` is OFF. It also monitors inbox replies and some bounce notices.
- Historical `Sent Emails` tab from the existing master tracker prevents duplicate contacts. Initial known bounces/declines are explicitly suppressed.

## Setup (one-time)

1. Make a **private** GitHub repository. Copy this folder into it. Enable Actions.
2. Use the existing master Sheet: `https://docs.google.com/spreadsheets/d/1U3JxQUcxSyqfZySnHNdLIwExtr3ikfcYlj0a3YY7ATM/edit`.
3. In Google Cloud, create a project, enable Google Sheets API, create a **service account**, download its JSON key. Share only the existing master Sheet with the service account email as **Editor**. Grant no Gmail privileges to it. Protect its private key.
4. Create a Groq API key on a free-eligible account and verify your current rate/token limits. Do **not** enable paid billing if cost must remain zero.
5. Add these **GitHub Actions repository secrets**: `SHEET_ID`, `GOOGLE_SERVICE_ACCOUNT_JSON`, `GROQ_API_KEY`. Add optional repo variable `GROQ_MODEL` (default `openai/gpt-oss-20b`). Never place secrets into CSV, Git history or logs.
6. Add real public-business targets to `config/seeds.csv` with columns `name,website,industry,source_url`. Optional `config/directories.csv` with permitted public directories; it follows **external website links only**. The starter **does not provide a general web search engine** or magically find 100 qualified leads. Fill seeds with enough trustworthy sources to reach the target.
7. GitHub **Actions > Discover and draft leads > Run workflow**. It creates `Lead Queue` if absent and inserts researched drafts. The workflow is also scheduled weekdays at 03:30 UTC (~09:00 IST), subject to GitHub scheduler availability.
8. In the master Sheet, open **Extensions > Apps Script**, paste `apps-script/Code.gs`. Set Project Settings > Script Properties: `SPREADSHEET_ID=1U3JxQUcxSyqfZySnHNdLIwExtr3ikfcYlj0a3YY7ATM`, `ENABLE_SENDING=NO`. Set script timezone to `Asia/Kolkata`.
9. Run `installTriggers()` once; approve Google permissions. Test discovery and draft verification first. After confirming send consent, sender reputation, approval workflow, and suppression list, change `ENABLE_SENDING` to `YES`. **Never set this during the first dry run.**
10. Approve each lead in `Lead Queue` by putting `APPROVED` in both `status` and `approval` columns. Sender checks nonblank proof, source URL, strict body length, deduplication and suppressions.

## Master Sheet lead queue columns

`lead_id, business, industry, website, source_url, public_email, email_source_url, observation, observation_url, proof_project, proof_line, subject, email_body, status, approval, sent_at, gmail_message_id, reply_status, notes, updated_at`

**Stages:** `AWAITING_REVIEW` → manually `APPROVED` → `SENDING` → `SENT` or `SEND_REVIEW`; `BOUNCED`, `DECLINED`, `SUPPRESSED` are terminal. Replies become `REPLY_REVIEW` and require a human decision. Existing master history is never deleted.

## Limits and known constraints

- **100 qualified** per discovery run is a **target, not a guarantee**. Pages may be blocked; source quality may be inadequate; Groq may throttle or fail; 120 AI calls and 500 HTTP fetches bound cost/time. Raise limits only after observing free-tier consumption.
- GitHub Actions scheduled jobs can be delayed or dropped; the free hosted runner allowance is finite for a private repository. There is no guaranteed 24/7 SLA.
- Gmail's daily send limit is separate from Apps Script quotas. The sender uses `Math.min(50 - sentToday, MailApp.getRemainingDailyQuota())`, and additionally pauses at the first ambiguity. Send counts are stored by IST day in Script Properties, not guaranteed to equal mailbox-wide daily totals (manual sends count against Google's quota).
- GmailApp.sendEmail does **not return a message ID**. The tracker intentionally stores a note instead of inventing one. `SENDING`/`SEND_REVIEW` records require manual reconciliation to avoid duplicate sends after timeouts.
- Inbox monitoring is basic pattern matching, not robust delivery verification. Unknown replies, forwarded messages, automatic responses, and bounce formats require review.
- `valid_email` only accepts same-domain public mailboxes and checks syntax. It does not verify that a mailbox exists or can receive mail; your earlier bounce rate was high. Consider email verification and deliberately small initial sending batches.
- Scraping must comply with site restrictions and applicable privacy/marketing laws. Never bypass authentication, robots controls or anti-bot protections. Add explicit opt-out instructions and process objections immediately before large-scale operation. Do not treat a public address as automatic marketing consent.
- This starter's source matching does not certify that the opportunity is objectively valuable; review each observation.

## Useful commands

```bash
pip install -r requirements.txt
pytest -q
python -m src.discover
```

## Production hardening before broad sending

- Improve directory discovery with domain-specific directory parsers and explicit allowlists.
- Add robots.txt checks, redirects/dns rebinding safeguards, institutional domain metadata and retry policies.
- Use a dedicated opt-out/suppression sheet and a standardized unsubscribe notice as appropriate for applicable laws.
- Add strong Gmail thread-id correlation and bounce parsing, quality QA tests, and per-campaign send budgets.
- Implement transactional/idempotent send-state reconciliation, audit logs and escalation notifications.
- Protect `Lead Queue` approval fields so only authorized reviewers can change them.
- Validate Groq JSON groundedness against evidence; currently the output is constrained but not fact-checked automatically.
