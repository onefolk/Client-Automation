"""Cloud-run institutional and multi-industry B2B discovery and drafting.
Only adds draft records to Google Sheets. Does NOT send email.
Uses user-provided seed/domain directories as permitted public sources; no Google Maps ToS bypass.
"""
import csv, json, logging, os, re, time
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag
import requests
from bs4 import BeautifulSoup
import gspread
from google.oauth2.service_account import Credentials

logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
ROOT = Path(__file__).resolve().parents[1]
HEADERS = ['lead_id','business','industry','website','source_url','public_email','email_source_url',
           'observation','observation_url','proof_project','proof_line','subject','email_body',
           'status','approval','sent_at','gmail_message_id','reply_status','notes','updated_at']
EMAIL = re.compile(r'(?<![\w.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.-])')
BAD_EMAIL = ('example.com','example.org','domain.com','wixpress.com','sentry.io','yourdomain.com')
CONTACT_WORDS = ('contact','about','admission','enquiry','inquiry','reach','team')
UA='OneFolk research bot (public pages; contact: contact.onefolk@gmail.com)'


def canonical(url):
    if not url: return ''
    if not url.startswith(('http://','https://')): url='https://'+url
    p=urlparse(url)
    return f'{p.scheme}://{p.netloc.lower()}{p.path.rstrip("/") or "/"}'

def domain(url):
    return (urlparse(canonical(url)).hostname or '').removeprefix('www.')

def valid_email(email, host):
    email=email.strip('.,;:!()[]<>"\'').lower()
    d=email.split('@')[-1]
    return ('@' in email and not any(d.endswith(b) for b in BAD_EMAIL)
            and not any(p in email for p in ('noreply','no-reply','support@wordpress','test@'))
            and (d==host or d.endswith('.'+host)))

def safe_url(url):
    p=urlparse(url)
    if p.scheme not in ('https','http'): return False
    h=(p.hostname or '').lower()
    if not h or h in ('localhost',) or h.endswith(('.local','.internal')): return False
    import ipaddress
    try:
        ip=ipaddress.ip_address(h)
        return ip.is_global
    except ValueError: return True

class Fetcher:
    def __init__(self):
        self.count=0; self.limit=int(os.getenv('MAX_HTTP_FETCHES','500'))
        self.session=requests.Session();self.session.headers.update({'User-Agent':UA})
    def html(self,url):
        if self.count>=self.limit or not safe_url(url): return None
        self.count+=1
        try:
            # redirects disabled to avoid accidental off-domain collection and internal URLs
            r=self.session.get(url,timeout=12,allow_redirects=False,headers={'Accept':'text/html'})
            if r.status_code in (301,302,307,308):
                loc=urljoin(url,r.headers.get('Location',''))
                if domain(loc)==domain(url) and safe_url(loc):
                    return self.html(loc)
                return None
            if r.status_code!=200 or 'html' not in r.headers.get('Content-Type','').lower():return None
            return r.text[:250000]
        except requests.RequestException: return None

def read_csv(name):
    with (ROOT/'config'/name).open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))

def candidates(fetch):
    found={}
    for row in read_csv('seeds.csv'):
        url=canonical(row.get('website',''))
        if safe_url(url) and domain(url):found[domain(url)]={'name':row.get('name','').strip() or domain(url),'website':url,'industry':row.get('industry','other').strip() or 'other','source_url':row.get('source_url','').strip() or url}
    maxlinks=int(os.getenv('MAX_DIRECTORY_LINKS','600'))
    links=0
    for row in read_csv('directories.csv'):
        directory=row.get('directory_url','')
        html=fetch.html(directory)
        if not html:continue
        for a in BeautifulSoup(html,'html.parser').select('a[href]'):
            if links>=maxlinks:break
            url=canonical(urljoin(directory,a.get('href','')))
            if not safe_url(url) or domain(url)==domain(directory):continue
            host=domain(url)
            if any(x in host for x in ('facebook.com','instagram.com','linkedin.com','youtube.com','google.com','maps.google','x.com','twitter.com')):continue
            title=a.get_text(' ',strip=True)[:120] or host
            found.setdefault(host,{'name':title,'website':f'https://{host}/','industry':row.get('industry','other') or 'other','source_url':directory})
            links+=1
    return list(found.values())

def investigate(lead,fetch):
    base=lead['website'];host=domain(base)
    main=fetch.html(base)
    if not main:return None
    soup=BeautifulSoup(main,'html.parser')
    urls=[base]
    for a in soup.select('a[href]'):
        url=urljoin(base,a['href'])
        if domain(url)==host and any(x in url.lower() for x in CONTACT_WORDS) and url not in urls:
            urls.append(url)
    extracted=[]; context=[]
    for url in urls[:4]:
        html=main if url==base else fetch.html(url)
        if not html:continue
        doc=BeautifulSoup(html,'html.parser')
        for tag in doc(['script','style','noscript','svg']):tag.decompose()
        txt=doc.get_text(' ',strip=True)
        for e in EMAIL.findall(txt+' '+str(doc.select('a[href^="mailto:"]'))):
            if valid_email(e,host):extracted.append((e.lower(),url))
        if url==base:context.append((txt[:6500],url))
        elif txt:context.append((txt[:3000],url))
    if not extracted:return None
    # prefer general institutional mailboxes over sensitive or individual addresses
    def priority(entry):
        local=entry[0].split('@')[0]
        prefs=['info','contact','office','admin','admissions','enquiry','hello','principal']
        return next((i for i,v in enumerate(prefs) if local==v),99)
    email,source=sorted(set(extracted),key=priority)[0]
    return {'email':email,'email_source':source,'contexts':context}

def groq(lead,findings,portfolio):
    api=os.getenv('GROQ_API_KEY','')
    if not api:return None
    matches=[p for p in portfolio if lead['industry'] in p['fits']]
    if not matches:matches=[p for p in portfolio if p['project']=='OneFolk website']
    proof=matches[0]
    sources=[{'url':url,'text':txt[:3500]} for txt,url in findings['contexts']]
    instruction={
      'task':'Identify ONE verifiable, meaningful website improvement opportunity using ONLY these page extracts; draft a truthful 3-line email.',
      'requirements':{'format':'JSON object: observation, observation_url, subject, email_body',
       'email_body':'Exactly 3 short paragraphs, under 70 words total. Paragraph 1: observed website issue or opportunity, no sender mention; paragraph 2: use exactly the supplied portfolio proof, no fabricated numeric results; paragraph 3: low-commitment question.',
       'no_issue':'If there is no genuinely specific and visible opportunity, return {"skip":true}. Never assume defects, conversion failures, or business outcomes.',
       'avoid':['invented facts','flattery','generic claims','urgency','attachments','name-dropping unsupported projects']},
      'institution':lead,'pages':sources,'approved_proof':proof['proof'],'approved_project':proof['project']}
    try:
        r=requests.post('https://api.groq.com/openai/v1/chat/completions',headers={'Authorization':'Bearer '+api,'Content-Type':'application/json'},json={'model':os.getenv('GROQ_MODEL','openai/gpt-oss-20b'),'temperature':0.1,'response_format':{'type':'json_object'},'messages':[{'role':'system','content':'You are a cautious B2B research assistant. Never fabricate website claims. Output valid JSON only.'},{'role':'user','content':json.dumps(instruction)}]},timeout=35)
        if r.status_code==429:raise RuntimeError('Groq rate limit; stop safely')
        r.raise_for_status()
        result=json.loads(r.json()['choices'][0]['message']['content'])
        if result.get('skip'):return None
        body=result.get('email_body','').strip();obs=result.get('observation','').strip()
        url=result.get('observation_url','').strip()
        if len(body.split())>70 or len(body.split('\n\n'))!=3 or not obs or url not in [u for _,u in findings['contexts']]:return None
        if proof['proof'] not in body:return None
        return {'observation':obs,'observation_url':url,'subject':result.get('subject','').strip()[:100], 'email_body':body,'proof':proof}
    except Exception as e:
        logging.warning('AI unable to draft for %s: %s',lead['name'],str(e)[:160]);return None

def connect():
    raw=os.environ['GOOGLE_SERVICE_ACCOUNT_JSON']
    creds=Credentials.from_service_account_info(json.loads(raw),scopes=['https://www.googleapis.com/auth/spreadsheets'])
    return gspread.authorize(creds).open_by_key(os.environ['SHEET_ID'])

def ensure_tab(book,name):
    try:return book.worksheet(name)
    except gspread.WorksheetNotFound:
        ws=book.add_worksheet(title=name,rows=2000,cols=len(HEADERS))
        ws.append_row(HEADERS,value_input_option='RAW')
        return ws

def main():
    book=connect();ws=ensure_tab(book,'Lead Queue');existing=ws.get_all_records()
    suppressed=set(); contacted=set()
    for row in existing:
        email=str(row.get('public_email','')).lower(); host=domain(str(row.get('website','')))
        if email:contacted.add(email)
        if str(row.get('status','')).upper() in ('BOUNCED','DECLINED','UNSUBSCRIBED','SUPPRESSED'):
            suppressed.update((email,host))
    try:
        historical=book.worksheet('Sent Emails').get_all_values()[1:]
        contacted.update(row[1].lower() for row in historical if len(row)>1)
    except gspread.WorksheetNotFound: pass
    for bad in ('info@drkumudiniaestheticgynae.com','team@studioamamumbai.com','contact@amazeoneinteriors.com','riointeriorsdesigner@gmail.com','studioha@gmail.com','hello@goristore.com','info@arch4foundation.com','dbs4mee@gmail.com'):
        suppressed.add(bad)
    fetch=Fetcher();portfolio=json.loads((ROOT/'config'/'portfolio.json').read_text())
    target=int(os.getenv('QUALIFIED_TARGET','100'));max_ai=int(os.getenv('MAX_AI_CALLS','120'))
    created=0; ai_used=0
    for lead in candidates(fetch):
        if created>=target or ai_used>=max_ai or fetch.count>=fetch.limit:break
        host=domain(lead['website'])
        if host in suppressed:continue
        info=investigate(lead,fetch)
        if not info or info['email'] in contacted or info['email'] in suppressed:continue
        ai_used+=1;out=groq(lead,info,portfolio)
        if not out:continue
        from datetime import datetime,timezone
        stamp=datetime.now(timezone.utc).isoformat()
        lead_id=__import__('hashlib').sha256((host+'|'+info['email']).encode()).hexdigest()[:20]
        vals=[lead_id,lead['name'],lead['industry'],lead['website'],lead['source_url'],info['email'],info['email_source'],out['observation'],out['observation_url'],out['proof']['project'],out['proof']['proof'],out['subject'],out['email_body'],'AWAITING_REVIEW','PENDING','','','','AI suggestion - review factual observation and contact suitability',stamp]
        ws.append_row(vals,value_input_option='RAW')
        created+=1;contacted.add(info['email'])
    logging.info('Finished: %s new drafts; %s AI calls; %s HTTP requests. No emails sent.',created,ai_used,fetch.count)

if __name__=='__main__':main()
